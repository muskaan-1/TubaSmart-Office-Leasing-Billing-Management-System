# TubaSmart Frontend

Angular frontend for the TubaSmart Office Leasing & Billing backend.

## Requirements
- Node.js 20+ (Node 22 is fine)
- npm
- TubaSmart Spring Boot backend running on `http://localhost:8080`

## Run
```bash
npm install
npm start
```
Open `http://localhost:4200`.

Development login configured by the supplied backend:
- Username: `admin`
- Password: `admin123`

## Backend API
The frontend calls `http://localhost:8080/api`. If your backend uses another port, change `base` in `src/app/core/api.service.ts` and `auth.service.ts`.

## Included screens
- Login
- Dashboard
- Company
- Customers / Tenants
- Buildings
- Floors
- Floor Prices
- Tenant Allotments
- Charge Schedules
- Charge Types
- Invoice Types
- SAC / HSN / GST
- Generate Billing
- Invoices
- Receipts

This frontend is intentionally aligned with the current backend endpoints. Some business workflows such as PDF invoice rendering, advanced reports, credit-note UI, role administration, and production-grade validation should be added after the backend rules are finalized.
