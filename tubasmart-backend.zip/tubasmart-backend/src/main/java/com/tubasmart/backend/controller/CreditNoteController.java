package com.tubasmart.backend.controller;

import com.tubasmart.backend.model.CreditNote;
import com.tubasmart.backend.repository.CreditNoteRepository;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/credit-notes")
public class CreditNoteController {
    private final CreditNoteRepository repo;
    public CreditNoteController(CreditNoteRepository repo){this.repo=repo;}
    @GetMapping public List<CreditNote> all(){return repo.findAll();}
    @GetMapping("/{id}") public CreditNote get(@PathVariable Long id){return repo.findById(id).orElseThrow();}
    @PostMapping public ResponseEntity<CreditNote> create(@RequestBody CreditNote x){return ResponseEntity.status(HttpStatus.CREATED).body(repo.save(x));}
    @PutMapping("/{id}") public CreditNote update(@PathVariable Long id,@RequestBody CreditNote x){x.getClass(); var old=repo.findById(id).orElseThrow(); return repo.save(copyId(x,old));}
    @DeleteMapping("/{id}") public ResponseEntity<Void> delete(@PathVariable Long id){repo.deleteById(id); return ResponseEntity.noContent().build();}
    private CreditNote copyId(CreditNote x,CreditNote old) {
        try { var f=com.tubasmart.backend.model.BaseEntity.class.getDeclaredField("id"); f.setAccessible(true); f.set(x, f.get(old)); } catch(Exception e){throw new RuntimeException(e);}
        return x;
    }
}
