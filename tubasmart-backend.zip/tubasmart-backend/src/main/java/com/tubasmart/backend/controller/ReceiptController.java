package com.tubasmart.backend.controller;

import com.tubasmart.backend.model.Receipt;
import com.tubasmart.backend.repository.ReceiptRepository;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/receipts")
public class ReceiptController {
    private final ReceiptRepository repo;
    public ReceiptController(ReceiptRepository repo){this.repo=repo;}
    @GetMapping public List<Receipt> all(){return repo.findAll();}
    @GetMapping("/{id}") public Receipt get(@PathVariable Long id){return repo.findById(id).orElseThrow();}
    @PostMapping public ResponseEntity<Receipt> create(@RequestBody Receipt x){return ResponseEntity.status(HttpStatus.CREATED).body(repo.save(x));}
    @PutMapping("/{id}") public Receipt update(@PathVariable Long id,@RequestBody Receipt x){x.getClass(); var old=repo.findById(id).orElseThrow(); return repo.save(copyId(x,old));}
    @DeleteMapping("/{id}") public ResponseEntity<Void> delete(@PathVariable Long id){repo.deleteById(id); return ResponseEntity.noContent().build();}
    private Receipt copyId(Receipt x,Receipt old) {
        try { var f=com.tubasmart.backend.model.BaseEntity.class.getDeclaredField("id"); f.setAccessible(true); f.set(x, f.get(old)); } catch(Exception e){throw new RuntimeException(e);}
        return x;
    }
}
