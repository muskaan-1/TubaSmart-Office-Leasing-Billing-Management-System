package com.tubasmart.backend.repository;
import com.tubasmart.backend.model.FloorPrice;
import org.springframework.data.jpa.repository.JpaRepository;
public interface FloorPriceRepository extends JpaRepository<FloorPrice, Long> {}
