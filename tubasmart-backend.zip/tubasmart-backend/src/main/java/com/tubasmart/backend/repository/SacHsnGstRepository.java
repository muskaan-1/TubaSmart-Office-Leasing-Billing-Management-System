package com.tubasmart.backend.repository;
import com.tubasmart.backend.model.SacHsnGst;
import org.springframework.data.jpa.repository.JpaRepository;
public interface SacHsnGstRepository extends JpaRepository<SacHsnGst, Long> {}
