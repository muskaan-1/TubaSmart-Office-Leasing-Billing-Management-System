package com.tubasmart.backend.model;
public enum Role { ADMIN, PROPERTY_LEASING, BILLING_FINANCE, MANAGEMENT }
