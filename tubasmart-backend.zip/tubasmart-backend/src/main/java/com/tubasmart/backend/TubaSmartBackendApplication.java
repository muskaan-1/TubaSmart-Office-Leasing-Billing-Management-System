package com.tubasmart.backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TubaSmartBackendApplication {
    public static void main(String[] args) {
        SpringApplication.run(TubaSmartBackendApplication.class, args);
    }
}
