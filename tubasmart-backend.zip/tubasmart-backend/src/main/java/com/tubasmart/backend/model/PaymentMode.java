package com.tubasmart.backend.model;
public enum PaymentMode { CASH, CHEQUE, BANK_TRANSFER, UPI, CARD, OTHER }
