package com.tubasmart.backend.repository;
import com.tubasmart.backend.model.TenantChargeSchedule;
import org.springframework.data.jpa.repository.JpaRepository;
public interface TenantChargeScheduleRepository extends JpaRepository<TenantChargeSchedule, Long> {}
