package com.tubasmart.backend.model;

import jakarta.persistence.*;
@Entity @Table(name="invoices", indexes={@Index(name="idx_invoice_period_tenant", columnList="billingPeriod,tenant_id")})
public class Invoice extends BaseEntity {
    @Column(nullable=false, unique=true) private String documentNumber;
    @ManyToOne(optional=false) private Customer tenant;
    @Column(nullable=false) private java.time.YearMonth billingPeriod;
    private java.time.LocalDate dueDate;
    private String supplyState;
    @Enumerated(EnumType.STRING) private DocumentStatus status = DocumentStatus.DRAFT;
    private java.math.BigDecimal subtotal = java.math.BigDecimal.ZERO, discount = java.math.BigDecimal.ZERO;
    private java.math.BigDecimal cgst = java.math.BigDecimal.ZERO, sgst = java.math.BigDecimal.ZERO, igst = java.math.BigDecimal.ZERO;
    private java.math.BigDecimal cess = java.math.BigDecimal.ZERO, tds = java.math.BigDecimal.ZERO, total = java.math.BigDecimal.ZERO;
    public String getDocumentNumber(){return documentNumber;} public void setDocumentNumber(String v){documentNumber=v;}
    public Customer getTenant(){return tenant;} public void setTenant(Customer v){tenant=v;}
    public java.time.YearMonth getBillingPeriod(){return billingPeriod;} public void setBillingPeriod(java.time.YearMonth v){billingPeriod=v;}
    public java.time.LocalDate getDueDate(){return dueDate;} public void setDueDate(java.time.LocalDate v){dueDate=v;}
    public String getSupplyState(){return supplyState;} public void setSupplyState(String v){supplyState=v;}
    public DocumentStatus getStatus(){return status;} public void setStatus(DocumentStatus v){status=v;}
    public java.math.BigDecimal getSubtotal(){return subtotal;} public void setSubtotal(java.math.BigDecimal v){subtotal=v;}
    public java.math.BigDecimal getDiscount(){return discount;} public void setDiscount(java.math.BigDecimal v){discount=v;}
    public java.math.BigDecimal getCgst(){return cgst;} public void setCgst(java.math.BigDecimal v){cgst=v;}
    public java.math.BigDecimal getSgst(){return sgst;} public void setSgst(java.math.BigDecimal v){sgst=v;}
    public java.math.BigDecimal getIgst(){return igst;} public void setIgst(java.math.BigDecimal v){igst=v;}
    public java.math.BigDecimal getCess(){return cess;} public void setCess(java.math.BigDecimal v){cess=v;}
    public java.math.BigDecimal getTds(){return tds;} public void setTds(java.math.BigDecimal v){tds=v;}
    public java.math.BigDecimal getTotal(){return total;} public void setTotal(java.math.BigDecimal v){total=v;}
}
