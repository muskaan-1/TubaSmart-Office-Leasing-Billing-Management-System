package com.tubasmart.backend.repository;
import com.tubasmart.backend.model.DocumentCounter;
import org.springframework.data.jpa.repository.JpaRepository;
public interface DocumentCounterRepository extends JpaRepository<DocumentCounter, Long> {
    java.util.Optional<DocumentCounter> findByDocumentTypeAndFinancialYear(String documentType, String financialYear);
}
