package com.tubasmart.backend.model;
public enum DocumentStatus { DRAFT, ISSUED, CANCELLED }
