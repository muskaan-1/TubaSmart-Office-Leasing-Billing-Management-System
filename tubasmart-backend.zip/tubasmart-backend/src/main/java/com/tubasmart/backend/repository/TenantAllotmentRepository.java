package com.tubasmart.backend.repository;
import com.tubasmart.backend.model.TenantAllotment;
import org.springframework.data.jpa.repository.JpaRepository;
public interface TenantAllotmentRepository extends JpaRepository<TenantAllotment, Long> {
    boolean existsByFloorIdAndActiveTrue(Long floorId);
}
