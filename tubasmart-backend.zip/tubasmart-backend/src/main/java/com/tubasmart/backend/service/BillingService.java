package com.tubasmart.backend.service;

import com.tubasmart.backend.model.*;
import com.tubasmart.backend.repository.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.*;

@Service
public class BillingService {
    private final InvoiceRepository invoices;
    private final CustomerRepository customers;
    private final TenantAllotmentRepository allotments;
    private final DocumentCounterRepository counters;

    public BillingService(InvoiceRepository invoices, CustomerRepository customers,
                          TenantAllotmentRepository allotments, DocumentCounterRepository counters) {
        this.invoices=invoices; this.customers=customers; this.allotments=allotments; this.counters=counters;
    }

    @Transactional
    public Invoice generate(Long tenantId, YearMonth period, BigDecimal taxableAmount, BigDecimal gstRate,
                            String supplyState, String companyState) {
        if (invoices.existsByTenantIdAndBillingPeriodAndStatusNot(tenantId, period, DocumentStatus.CANCELLED))
            throw new IllegalStateException("Invoice already exists for this tenant and billing period");

        Customer tenant=customers.findById(tenantId).orElseThrow();
        var activeAllotments=allotments.findAll().stream()
                .filter(a->a.isActive() && a.getTenant().getId().equals(tenantId))
                .toList();
        if(activeAllotments.isEmpty()) throw new IllegalStateException("No active tenant allotment found");

        Invoice i=new Invoice();
        i.setTenant(tenant);
        i.setBillingPeriod(period);
        i.setSupplyState(supplyState);
        i.setDueDate(period.atDay(1).plusDays(Math.max(0,tenant.getCreditDays())));
        i.setDocumentNumber(nextNumber("INV", period));
        i.setStatus(DocumentStatus.ISSUED);
        i.setSubtotal(money(taxableAmount));

        BigDecimal tax=taxableAmount.multiply(gstRate).divide(BigDecimal.valueOf(100),2,RoundingMode.HALF_UP);
        if(supplyState!=null && supplyState.equalsIgnoreCase(companyState)) {
            i.setCgst(tax.divide(BigDecimal.valueOf(2),2,RoundingMode.HALF_UP));
            i.setSgst(tax.subtract(i.getCgst()));
        } else {
            i.setIgst(tax);
        }
        BigDecimal gross=taxableAmount.add(i.getCgst()).add(i.getSgst()).add(i.getIgst());
        i.setTotal(money(gross));
        return invoices.save(i);
    }

    private String nextNumber(String type, YearMonth p) {
        String fy=(p.getMonthValue()>=4?p.getYear():p.getYear()-1)+"-"+(p.getMonthValue()>=4?p.getYear()+1:p.getYear());
        var c=counters.findByDocumentTypeAndFinancialYear(type,fy).orElseGet(()->{
            var n=new DocumentCounter(); n.setDocumentType(type); n.setFinancialYear(fy); return n;
        });
        c.setLastNumber(c.getLastNumber()+1); counters.save(c);
        return type+"/"+fy+"/"+String.format("%05d",c.getLastNumber());
    }
    private BigDecimal money(BigDecimal x){return x.setScale(2,RoundingMode.HALF_UP);}
}
