package com.tubasmart.backend.repository;
import com.tubasmart.backend.model.Building;
import org.springframework.data.jpa.repository.JpaRepository;
public interface BuildingRepository extends JpaRepository<Building, Long> {}
