package com.tubasmart.backend.repository;
import com.tubasmart.backend.model.InvoiceType;
import org.springframework.data.jpa.repository.JpaRepository;
public interface InvoiceTypeRepository extends JpaRepository<InvoiceType, Long> {}
