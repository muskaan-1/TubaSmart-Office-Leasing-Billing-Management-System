package com.tubasmart.backend.controller;

import com.tubasmart.backend.repository.*;
import org.springframework.web.bind.annotation.*;
import java.util.*;

@RestController @RequestMapping("/api/reports")
public class ReportController {
    private final InvoiceRepository invoices; private final ReceiptRepository receipts;
    public ReportController(InvoiceRepository i, ReceiptRepository r){invoices=i;receipts=r;}
    @GetMapping("/{reportName}")
    public Object report(@PathVariable String reportName){
        return switch(reportName){
            case "invoice-register" -> invoices.findAll();
            case "receipts" -> receipts.findAll();
            default -> Map.of("report",reportName,"message","Report endpoint reserved for implementation of source-defined report filters.");
        };
    }
}
