package com.tubasmart.backend.model;

import jakarta.persistence.*;
@Entity @Table(name="companies")
public class Company extends BaseEntity {
    @Column(nullable=false) private String name;
    private String gstin, panCin, bankDetails, upi, logoPath, signatory;
    public String getName(){return name;} public void setName(String v){name=v;}
    public String getGstin(){return gstin;} public void setGstin(String v){gstin=v;}
    public String getPanCin(){return panCin;} public void setPanCin(String v){panCin=v;}
    public String getBankDetails(){return bankDetails;} public void setBankDetails(String v){bankDetails=v;}
    public String getUpi(){return upi;} public void setUpi(String v){upi=v;}
    public String getLogoPath(){return logoPath;} public void setLogoPath(String v){logoPath=v;}
    public String getSignatory(){return signatory;} public void setSignatory(String v){signatory=v;}
}
