package com.tubasmart.backend.model;
public enum FloorStatus { OCCUPIED, VACANT_READY, UNDER_REPAIR, FIT_OUT, BLOCKED }
