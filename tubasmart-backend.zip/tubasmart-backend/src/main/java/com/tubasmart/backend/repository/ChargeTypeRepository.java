package com.tubasmart.backend.repository;
import com.tubasmart.backend.model.ChargeType;
import org.springframework.data.jpa.repository.JpaRepository;
public interface ChargeTypeRepository extends JpaRepository<ChargeType, Long> {}
