package com.tubasmart.backend.controller;

import com.tubasmart.backend.model.Invoice;
import com.tubasmart.backend.repository.InvoiceRepository;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/invoices")
public class InvoiceController {
    private final InvoiceRepository repo;
    public InvoiceController(InvoiceRepository repo){this.repo=repo;}
    @GetMapping public List<Invoice> all(){return repo.findAll();}
    @GetMapping("/{id}") public Invoice get(@PathVariable Long id){return repo.findById(id).orElseThrow();}
    @PostMapping public ResponseEntity<Invoice> create(@RequestBody Invoice x){return ResponseEntity.status(HttpStatus.CREATED).body(repo.save(x));}
    @PutMapping("/{id}") public Invoice update(@PathVariable Long id,@RequestBody Invoice x){x.getClass(); var old=repo.findById(id).orElseThrow(); return repo.save(copyId(x,old));}
    @DeleteMapping("/{id}") public ResponseEntity<Void> delete(@PathVariable Long id){repo.deleteById(id); return ResponseEntity.noContent().build();}
    private Invoice copyId(Invoice x,Invoice old) {
        try { var f=com.tubasmart.backend.model.BaseEntity.class.getDeclaredField("id"); f.setAccessible(true); f.set(x, f.get(old)); } catch(Exception e){throw new RuntimeException(e);}
        return x;
    }
}
