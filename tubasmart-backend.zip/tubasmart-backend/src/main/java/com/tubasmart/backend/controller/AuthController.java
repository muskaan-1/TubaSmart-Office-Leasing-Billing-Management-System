package com.tubasmart.backend.controller;

import com.tubasmart.backend.security.JwtService;
import jakarta.validation.constraints.NotBlank;
import org.springframework.web.bind.annotation.*;

@RestController @RequestMapping("/api/auth")
public class AuthController {
    private final JwtService jwt;
    public AuthController(JwtService jwt){this.jwt=jwt;}

    public record LoginRequest(@NotBlank String username, @NotBlank String password) {}
    public record LoginResponse(String token, String role) {}

    @PostMapping("/login")
    public LoginResponse login(@RequestBody LoginRequest r) {
        // Development authentication placeholder. Replace with users/roles table + PasswordEncoder.
        if (!"admin".equals(r.username()) || !"admin123".equals(r.password()))
            throw new org.springframework.web.server.ResponseStatusException(
                    org.springframework.http.HttpStatus.UNAUTHORIZED, "Invalid credentials");
        return new LoginResponse(jwt.generate(r.username(), "ADMIN"), "ADMIN");
    }
}
