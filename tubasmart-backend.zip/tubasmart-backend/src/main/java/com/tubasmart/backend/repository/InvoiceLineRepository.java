package com.tubasmart.backend.repository;
import com.tubasmart.backend.model.InvoiceLine;
import org.springframework.data.jpa.repository.JpaRepository;
public interface InvoiceLineRepository extends JpaRepository<InvoiceLine, Long> {}
