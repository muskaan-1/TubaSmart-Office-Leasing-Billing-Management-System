package com.tubasmart.backend.controller;

import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import java.time.OffsetDateTime;
import java.util.Map;

@RestControllerAdvice
public class ApiExceptionHandler {
    @ExceptionHandler(Exception.class)
    ResponseEntity<?> handle(Exception e){
        return ResponseEntity.badRequest().body(Map.of("timestamp", OffsetDateTime.now(),
            "error","BAD_REQUEST","message",e.getMessage()==null?"Request failed":e.getMessage()));
    }
}
