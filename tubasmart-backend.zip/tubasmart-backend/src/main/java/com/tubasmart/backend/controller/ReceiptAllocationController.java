package com.tubasmart.backend.controller;

import com.tubasmart.backend.model.ReceiptAllocation;
import com.tubasmart.backend.repository.ReceiptAllocationRepository;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/receipts/allocations")
public class ReceiptAllocationController {
    private final ReceiptAllocationRepository repo;
    public ReceiptAllocationController(ReceiptAllocationRepository repo){this.repo=repo;}
    @GetMapping public List<ReceiptAllocation> all(){return repo.findAll();}
    @GetMapping("/{id}") public ReceiptAllocation get(@PathVariable Long id){return repo.findById(id).orElseThrow();}
    @PostMapping public ResponseEntity<ReceiptAllocation> create(@RequestBody ReceiptAllocation x){return ResponseEntity.status(HttpStatus.CREATED).body(repo.save(x));}
    @PutMapping("/{id}") public ReceiptAllocation update(@PathVariable Long id,@RequestBody ReceiptAllocation x){x.getClass(); var old=repo.findById(id).orElseThrow(); return repo.save(copyId(x,old));}
    @DeleteMapping("/{id}") public ResponseEntity<Void> delete(@PathVariable Long id){repo.deleteById(id); return ResponseEntity.noContent().build();}
    private ReceiptAllocation copyId(ReceiptAllocation x,ReceiptAllocation old) {
        try { var f=com.tubasmart.backend.model.BaseEntity.class.getDeclaredField("id"); f.setAccessible(true); f.set(x, f.get(old)); } catch(Exception e){throw new RuntimeException(e);}
        return x;
    }
}
