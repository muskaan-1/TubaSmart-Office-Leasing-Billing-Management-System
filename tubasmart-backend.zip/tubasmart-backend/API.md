# TubaSmart Backend API starter

Base URL: `http://localhost:8080`

## Auth
- POST `/api/auth/login`

## Masters
- GET/POST `/api/company`
- GET/POST `/api/masters/sac-hsn`
- GET/POST `/api/masters/charge-types`
- GET/POST `/api/masters/invoice-types`
- GET/POST `/api/masters/customers`
- GET/POST `/api/masters/buildings`
- GET/POST `/api/masters/floors`
- GET/POST `/api/masters/floor-prices`
- GET/POST `/api/masters/allotments`
- GET/POST `/api/masters/charge-schedules`

## Billing
- POST `/api/billing/runs/generate`
- GET/POST `/api/invoices`
- GET/POST `/api/receipts`
- GET/POST `/api/credit-notes`

## Dashboard / reports
- GET `/api/dashboard`
- GET `/api/reports/invoice-register`
- GET `/api/reports/receipts`

The remaining source-defined report names can be added after the exact report filters and layouts are confirmed.
