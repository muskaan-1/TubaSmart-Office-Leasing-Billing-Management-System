# TubaSmart Backend — Spring Boot + Java + PostgreSQL

Backend-only implementation starter for the TubaSmart Office Leasing Billing Solution.

## Source alignment
The supplied plan specifies Angular + Spring Boot + Java SE, PostgreSQL, REST/JSON, Spring Security + RBAC + JWT, server-side PDF generation, and the backend flow Controller → DTO → Service → Repository → Entity → PostgreSQL. It also requires duplicate-billing prevention, receipt allocation controls, credit-note limits, validation and transactional consistency.

## Implemented
- Spring Boot REST API
- PostgreSQL/JPA persistence
- JWT authentication endpoint (development admin login)
- Role-ready Spring Security
- Company, tax, charge, invoice type, customer, building, floor, pricing and allotment masters
- Tenant charge schedules
- Invoice, receipt, receipt allocation and credit note models
- Billing generation service with duplicate-period protection
- GST intra/inter-state split
- Non-reusable invoice document counter
- Dashboard and report starter endpoints
- Global API error response
- Environment-variable configuration
- Docker Compose for PostgreSQL

## Run
1. Start PostgreSQL:
   `docker compose up -d postgres`
2. Run:
   `mvn spring-boot:run`
3. Login:
   `POST /api/auth/login`
   body: `{"username":"admin","password":"admin123"}`
4. Use the returned JWT:
   `Authorization: Bearer <token>`

## Important
This is a backend foundation, not a claim that every undefined business rule is finalized. The supplied document explicitly lists rent/proration, escalation, late fees, GST/TDS edge cases, invoice numbering/cancellation, reconciliation/refunds, hosting/concurrency and migration as items requiring confirmation.
